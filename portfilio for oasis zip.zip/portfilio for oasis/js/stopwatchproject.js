let m=0;
let s=0;
let h=0;
let timerid;
function setminute(){
    m+=1;
    if(m<10){
        document.getElementById("minutes").innerText='0' + m;
    }
    else{
        document.getElementById("minutes").innerText=m;
    }
}
function setsecond()
{
    s+=1;
    if(s==60)
    {
        s=0;
        setminute();
    }
    if(s<10){
        document.getElementById("seconds").innerText='0' + s;
    }
    else
    {
        document.getElementById("seconds").innerText= s;
    }
}

function startstopwatch(){
    h=h+1;
    if(h==100){
        h=0;
        setsecond();
    }
    if(h<10){
        document.getElementById("hours").innerText='0' + h;
    }
    else{
        document.getElementById("hours").innerText= h;
    }
}
function start()
{
    timerid = setInterval(startstopwatch,10)

}
function stop()
{
    clearInterval(timerid);
}
function reset()
{
    document.getElementById("minutes").innerText= "00";
    document.getElementById("seconds").innerText="00";
    document.getElementById("hours").innerText="00";
    stop();
h=0;
s=0;
m=0;
}





 